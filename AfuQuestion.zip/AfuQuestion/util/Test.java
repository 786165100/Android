package util;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws Exception {

		Connection conn = ConnUtil.getConn();
		User user = new User();
		String sql = "Select * from user where username= ? and password = ? ";
		PreparedStatement pre = conn.prepareStatement(sql);
		pre.setString(1, "yangkai");
		pre.setString(2, "123456");
		ResultSet set = pre.executeQuery();
		if (set.next()) {
			user.setId(set.getString("id"));
			user.setUsername(set.getString("username"));
			user.setPassword(set.getString("password"));
			user.setMass(set.getString("mass"));
			System.out.println(user.toString());

			System.out.println("��½�ɹ�");
		} else {
			System.out.println("�û����������벻��");
		}

	}

}
