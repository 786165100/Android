package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection conn = DriverManager.getConnection("jdbc:mysql://115.159.3.124:3306/afu?user=root&password=qwerty12");
			System.out.println(conn);
			Statement stmt = conn.createStatement();
			String sql = "Select * from user ";
			ResultSet set = stmt.executeQuery(sql);
			set.next();
			System.out.println(set.getString(2));
			System.out.println("��½�ɹ�");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
