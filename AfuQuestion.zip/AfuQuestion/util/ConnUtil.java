package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnUtil {

	public static Connection getConn() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			return DriverManager.getConnection("jdbc:mysql://115.159.3.124:3306/afu?rewriteBatchedStatements=true",
					"root", "qwerty12");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void myclose(Connection conn, PreparedStatement pre, ResultSet set) {
		try {
			if (conn != null) {
				conn.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (set != null) {
				set.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
